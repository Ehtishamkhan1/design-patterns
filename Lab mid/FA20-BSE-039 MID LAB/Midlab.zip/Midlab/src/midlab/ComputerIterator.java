/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package midlab;

/**
 *
 * @author ehtis
 */
interface ComputerIterator {
    boolean hasNext();
    Computer next();
}

